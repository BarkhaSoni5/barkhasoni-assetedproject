package asseted3;

public class CircularLinkedList {
	
	int data;
	CircularLinkedList next;
  
	CircularLinkedList(int d)
    {
        data = d;
        next = null;
    }

}
