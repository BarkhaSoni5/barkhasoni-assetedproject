package asseted3;

public class CircularLinkedList1 {
	
	CircularLinkedList head;
	  
	CircularLinkedList1()   { head = null; }

	void sortedInsert(CircularLinkedList new_node)
    {
    	CircularLinkedList current = head;
  
        if (current == null)
        {
            new_node.next = new_node;
            head = new_node;
  
        }
  
        else if (current.data >= new_node.data)
        {
  
            while (current.next != head)
                current = current.next;
  
            current.next = new_node;
            new_node.next = head;
            head = new_node;
        }
  
        else
        {
  
            while (current.next != head &&
                   current.next.data < new_node.data)
                current = current.next;
  
            new_node.next = current.next;
            current.next = new_node;
        }
    }
  
    void printList()
    {
        if (head != null)
        {
        	CircularLinkedList temp = head;
            do
            {
                System.out.print(temp.data + " ");
                temp = temp.next;
            }  while (temp != head);
        }
    }

	public static void main(String[] args) {
		
		CircularLinkedList1 list = new CircularLinkedList1();
		  
        int arr[] = new int[] {45, 12, 90, -67, 12, 23};
  
        CircularLinkedList temp = null;

        for (int i = 0; i < 6; i++)
        {
            temp = new CircularLinkedList(arr[i]);
            list.sortedInsert(temp);
        } 
        list.printList();

	}

}
