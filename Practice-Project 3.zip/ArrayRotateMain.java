package asseted3;

public class ArrayRotateMain {

	public static void main(String[] args) {
		
		ArrayRotate r = new ArrayRotate();
		int a[] = { 10,20,30,40,50,60,70,80 }; 
		r.rotate(a, 5); 
		for(int i=0;i<a.length;i++){
    			System.out.print(a[i]+" ");
		}


	}

}
