package assetedproject2;

public class ThreadSample2 implements Runnable {
	public void run() {
		System.out.println("Thread activated again ......");
	}

	public static void main(String[] args) {
		ThreadSample2 th1=new ThreadSample2();
		Thread ts1=new Thread(th1);
		ts1.start();

	}

}
