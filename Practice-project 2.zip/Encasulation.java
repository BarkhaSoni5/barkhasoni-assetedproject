package assetedproject2;

public class Encasulation {

	public static void main(String[] args) {
		Encapsulate1 obj = new Encapsulate1(); 
        obj.setName("Barkha"); 
        obj.setAge(23); 
        obj.setRoll(13); 
        System.out.println("My name: " + obj.getName()); 
        System.out.println("My age: " + obj.getAge()); 
        System.out.println("My roll: " + obj.getRoll());
        
        System.out.println("-----------------------");
        
        Encapsulate1 obj2 = new Encapsulate1(); 
        obj.setName("Aniket"); 
        obj.setAge(21); 
        obj.setRoll(17); 
        System.out.println("My name: " + obj.getName()); 
        System.out.println("My age: " + obj.getAge()); 
        System.out.println("My roll: " + obj.getRoll());



	}

}
