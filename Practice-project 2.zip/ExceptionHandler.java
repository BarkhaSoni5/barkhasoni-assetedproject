package assetedproject2;

class Exception2 extends Exception{
	   String s1;
	   Exception2(String s2) {
		s1=s2;
	   }
	   public String toString(){ 
		return ("MyException Occurred: "+s1) ;
	   }
	}

public class ExceptionHandler {

	public static void main(String[] args) {
		try{
			System.out.println("Try block  starts here...........");
			// I'm throwing the custom exception using throw
			throw new Exception2("error message in throw block..........");
		}
		catch(Exception2 e1){
			System.out.println("Catch Block here...........") ;
			System.out.println(e1) ;
		}


	}

}
