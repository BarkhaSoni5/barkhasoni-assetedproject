import java.io.*;

public class AppendFile
{
   public static void main(String[] args)
   {
      try
      {
         FileWriter fw = new FileWriter("data.txt", true);
         fw.write("\nI'm the new content.");
         fw.close();
         System.out.println("The content is successfully appended to the file.");
      }
      catch(IOException ioe)
      {
         System.out.print("\nSomething went wrong!");
      }
   }
}
