package assetedproject2;
//program for polymorphism
public class Area {
	public int rectangle(int x, int y) 
    { 
        return (x * y); 
    } 
    public int cuboid(int x, int y, int z) 
    { 
        return (x * y * z); 
    } 
    public double square(double x) 
    { 
        return (x*x);
    }


	public static void main(String[] args) {
		Area a = new Area(); 
        System.out.println("Area of Rectangle : "+a.rectangle(10, 20)); 
        System.out.println("Area of Cuboid : "+a.cuboid(10, 20, 30)); 
        System.out.println("Area of Square : "+a.square(10.5));


	}

}
