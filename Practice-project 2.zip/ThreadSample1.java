package assetedproject2;

public class ThreadSample1 extends Thread{
	public void run() {
		System.out.println("thread activated.......");
	}
	
	

	public static void main(String[] args) {
		ThreadSample1 ts1=new ThreadSample1();
		ts1.start();
		

	}

}
