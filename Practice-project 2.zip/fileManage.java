
import java.io.File;
import java.io.IOException;

public class fileManage {
	
			public static void main(String[] args) {
			
			File myFile = new File("data.txt");
			try {
				if (myFile.createNewFile()) {
					System.out.println("File Create");
					
				}
				else {
					System.out.println("error to create file");
				}
			} catch (IOException e) {
				System.out.println("File error.....");
			}
			
			

		}

	}



