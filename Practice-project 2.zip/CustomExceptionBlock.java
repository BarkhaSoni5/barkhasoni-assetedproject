package assetedproject2;
class Exception2 extends Exception 
{ 
    public Exception2(String s) 
    { 
        super(s); 
    } 
} 

public class CustomExceptionBlock {

	public static void main(String[] args) {
		try
        { 
            throw new Exception2("Try block"); 
        } 
        catch (Exception2 ex) 
        { 
            System.out.println("Caught block"); 
            System.out.println(ex.getMessage()); 
        } 


	}

}
