package assetedproject2;
//program for objects and classes
public class Students {
	String name; 
    int age; 
    String course; 
    
	public Students(String name, int age, String course) {
		super();
		this.name = name;
		this.age = age;
		this.course = course;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}
	
	public String getCourse() {
		return course;
	}
	
	@Override
	 public String toString() 
    { 
        return("Name of the student is "+ this.getName()+ " of age " 
    + this.getAge()+ " and the course is "+ this.getCourse() + "."); 
    }


	public static void main(String[] args) {
		 Students s1 = new Students("Barkha", 23, "java"); 
	     System.out.println(s1.toString());
	     
	     Students s2 = new Students("Aniket", 21, "python"); 
	     System.out.println(s2.toString());



	}

}
