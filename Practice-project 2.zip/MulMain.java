package assetedproject2;

class Demo1
{
	protected int x;
	public Demo1(int x)
	{
		this.x = x;
		System.out.println("Parent class.......");
	}
}

class Demo2 extends Demo1
{
	private int y;
	public Demo2(int a, int b)
	{
		super(a);
		this.y = b;
	System.out.println("Child Class........");
	}
	
	public void print()
	{
		System.out.println("X value is : " + x);
		System.out.println("Y value is : " + y);
	}
}


public class MulMain {

	public static void main(String[] args) {
		Demo2 d2 = new Demo2(34,56);
		d2.print();


	}

}
