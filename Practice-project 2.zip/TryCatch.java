package assetedproject2;

public class TryCatch {

	public static void main(String[] args) {
		try  
        {  
        int a[]= {11,3,5,6,7,8};  
        System.out.println(a[10]);    
        }  
            
        catch(ArrayIndexOutOfBoundsException e)  
        {  
        	System.out.println("This is Array index out of bound error");
            System.out.println(e);  
        }  
        System.out.println("try catch block ends here");
     

	}

}
