package assetedproject2;


public class SleepAndWait {
	private static Object n=new Object();


	public static void main(String[] args) throws InterruptedException
	{
		Thread.sleep(1000);   
        System.out.println( Thread.currentThread().getName() +" Thread is woken after one second");   
        
        synchronized (n)    
        {   
            n.wait(3000);   
            System.out.println(n + " Object is in waiting state and woken after 3 seconds");   
        }   

	}

}
