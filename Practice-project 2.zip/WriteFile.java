import java.io.FileWriter;   
import java.io.IOException;  

public class WriteFile {
  public static void main(String[] args) {
    try {
      FileWriter myFile = new FileWriter("data.txt");
      myFile.write("Writing the first file using java");
      myFile.close();
      System.out.println("Successfully written in the file.............");
    } catch (IOException e) {
      System.out.println("Error occurred............");
      e.printStackTrace();
    }
  }
}