package assetedproject2;

public class FinallyBlock {

	public static void main(String[] args) {
		int a=50,b=5,r=0;
        try
        {
            r = a / b;
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("Error is: " + Ex.getMessage());
        }
        finally
        {
            System.out.print("The result is : " + r);
        }


	}

}
