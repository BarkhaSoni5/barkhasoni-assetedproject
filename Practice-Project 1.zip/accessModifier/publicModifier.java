package accessModifier;
import asseted1.*;

public class publicModifier extends protectedAccess {

	public static void main(String[] args) {
		publicModifier a=new publicModifier();
		a.display();

	}

}
