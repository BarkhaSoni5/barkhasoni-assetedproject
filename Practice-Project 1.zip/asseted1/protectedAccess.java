package asseted1;

public class protectedAccess {
	protected void display() {
		System.out.println("this is protected access modifier");
	}
	

}
