package asseted1;

public class Method1 {
	public int addition(int a,int b){
		int c;
		c=a+b;
		return c;
	}

	public static void main(String[] args) {
		
		Method1 n = new Method1();
		int d=n.addition(50,10);
		System.out.println("Addition of two numbers : "+d);

	}

}
