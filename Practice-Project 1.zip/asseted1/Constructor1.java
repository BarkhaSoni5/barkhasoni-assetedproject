package asseted1;
//default constructor
public class Constructor1 {
	
	int studentid;
	String name;
	float marks;
	
	public void display() {
		System.out.println("this is student id "+studentid+" and name "+name+ " with marks "+marks);
	}

	public static void main(String[] args) {
		
		Constructor1 s1 = new Constructor1();
		Constructor1 s2 =new Constructor1();
		
		s1.display();
		s2.display();
		

	}

}
