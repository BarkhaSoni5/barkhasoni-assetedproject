package asseted1;

public class Constructor2 {
	int studentid;
	String studentname;
	
	public Constructor2(int id, String name){
		studentid = id;
		studentname = name;
	}
	
	public void display() {
		System.out.println("this is student id "+studentid+" and name "+studentname);
	}

	public static void main(String[] args) {
		 Constructor2 s1= new Constructor2(01,"barkha");
		 Constructor2 s2= new Constructor2(02,"aniket");
		 Constructor2 s3= new Constructor2(03,"swarna");
		 Constructor2 s4= new Constructor2(04,"swati");
		 
		 s1.display();
		 s2.display();
		 s3.display();
		 s4.display();
		 
		 
		 

	}

}
