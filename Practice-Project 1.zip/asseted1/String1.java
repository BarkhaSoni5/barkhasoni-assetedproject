package asseted1;

public class String1 {

	public static void main(String[] args) {
		
		// string methods
		String s1="Hello Java";
		String s2="Welcome to Java World";
		
		System.out.println(s1.toUpperCase());
		System.out.println(s2.toLowerCase());
		System.out.println(s1.charAt(2));
		System.out.println(s2.charAt(5));
		
		System.out.println(s1.concat(s2));
		
		System.out.println("------------------");
		
		//string buffer
		StringBuffer s3=new StringBuffer ("Java is Object Oriented Programming Language ");
		
		System.out.println(s3.append("Have a Great Day"));
		
		System.out.println(s3.insert(7,'a'));
		
		System.out.println(s3.replace(0,4,"JAVA"));
		
		System.out.println("------------------------");
		
		// string builder
		StringBuilder s4=new StringBuilder ("Have Happy Learning ");
		
        System.out.println(s4.append("And A Great Day"));
		
		System.out.println(s4.insert(5,"A Very "));
				
		System.out.println(s4.delete(0,3));
		
		System.out.println("------------------------------");
		
		//Converting string to String Buffer
		String s5="Hello Everyone";
		StringBuffer s6 = new StringBuffer(s5); 
        s6.reverse(); 
        System.out.println(s6); 
          
        // converting String to StringBuilder 
        StringBuilder s7 = new StringBuilder(s5); 
        s7.append("world"); 
        System.out.println(s7);              		

		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
