package asseted1;

class defaultAccessModifier{
	void display()
	{
		System.out.println("This is Default Modifier");
	}
}

public class AccessModifier {

	public static void main(String[] args) {
		
		System.out.println("Default Access Modifier");
		defaultAccessModifier n=new defaultAccessModifier();
		n.display();

	}

}
