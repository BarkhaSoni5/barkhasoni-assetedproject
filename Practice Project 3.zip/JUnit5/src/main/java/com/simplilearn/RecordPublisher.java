package com.simplilearn;

public interface RecordPublisher {
	public boolean publish();

}
