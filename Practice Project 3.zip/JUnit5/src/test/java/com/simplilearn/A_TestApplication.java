package com.simplilearn;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
public class A_TestApplication {

	@BeforeAll
	static void initAll() {
		System.out.println("BeforeAll in invoked");
	}
	
	@BeforeEach
	void initMe() {
		System.out.println("BeforeEach init() in invoked");
	}
	
	@Test
	void success() {
		//logic of test cases
		System.out.println("@Test success() in invoked");
		
	}
	
	@Test
	void success1() {
		//logic of test cases
		System.out.println("@Test success1() in invoked");
		
	}
	
	@AfterEach
	void afterEach() {
		System.out.println("AfterEach afterEach() in invoked");
	}
	
	@AfterAll
	static void destroyAll() {
		System.out.println("AfterAll in invoked");
	}
}
